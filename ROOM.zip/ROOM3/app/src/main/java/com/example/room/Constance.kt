package com.example.room

const val DATABASE_NAME ="DB"